# Changelog

## 3.0.0
- Added support for parsing HTML filtering rules
